def count_up(max):
    for i in range(max):
        print(i, end=', ')
